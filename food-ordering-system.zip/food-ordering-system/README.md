# FoodHub — Full-Stack Food Ordering System

A complete food ordering platform: customers browse restaurants and menus, search/filter dishes, manage a real-time cart, check out, and track orders. Admins get a dashboard to manage the menu and update order statuses.

Built and tested end-to-end:
- **Backend**: Node.js + Express REST API, JWT authentication, bcrypt password hashing, JSON file storage (via lowdb) — no external database required.
- **Frontend**: React 18 (Create React App), React Router, Context API for auth/cart state, Axios for API calls.
- **Design**: A custom "order ticket" visual identity (Fraunces + Inter + JetBrains Mono, saffron/chili/basil palette), responsive down to mobile.

## Project structure

```
food-ordering-system/
├── backend/                 Express REST API
│   ├── server.js            App entry point
│   ├── db.json               Seed data (users, restaurants, menu items, orders)
│   ├── routes/                auth.js, menu.js, orders.js
│   ├── middleware/auth.js     JWT verification + role-based access control
│   └── utils/db.js            lowdb JSON database wrapper
└── frontend/                 React app
    ├── src/
    │   ├── api/api.js         Axios client + all API calls
    │   ├── context/           AuthContext, CartContext
    │   ├── components/        Navbar, MenuItemCard, ProtectedRoute
    │   └── pages/              Home, Login, Register, Checkout,
    │                            OrderConfirmation, OrderHistory, admin/
    └── public/index.html
```

## Getting started

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env      # edit JWT_SECRET for anything beyond local testing
npm start                  # or: npm run dev (with nodemon)
```

Runs on **http://localhost:5000**. Health check: `GET /api/health`.

### 2. Frontend

In a separate terminal:

```bash
cd frontend
npm install
npm start
```

Runs on **http://localhost:3000** and proxies API calls to the backend automatically (see the `"proxy"` field in `frontend/package.json`).

### 3. Log in

A demo admin account is seeded for you:

- **Email:** `admin@foodhub.com`
- **Password:** `admin123`

Or create a new customer account from the Sign up page.

## API reference

| Method | Endpoint                  | Auth        | Description                          |
|--------|----------------------------|-------------|---------------------------------------|
| POST   | `/api/auth/register`       | —           | Create a customer account             |
| POST   | `/api/auth/login`          | —           | Log in, returns a JWT                 |
| GET    | `/api/auth/me`              | Bearer      | Get the current user                  |
| GET    | `/api/restaurants`          | —           | List restaurants                      |
| GET    | `/api/menu`                 | —           | List/search/filter menu items         |
| GET    | `/api/menu/:id`             | —           | Get one menu item                     |
| POST   | `/api/menu`                  | Admin       | Create a menu item                    |
| PUT    | `/api/menu/:id`              | Admin       | Update a menu item                    |
| DELETE | `/api/menu/:id`              | Admin       | Delete a menu item                    |
| POST   | `/api/orders`                 | Bearer      | Place an order (prices re-validated server-side) |
| GET    | `/api/orders/mine`            | Bearer      | Get the current user's orders         |
| GET    | `/api/orders/:id`              | Bearer      | Get one order (owner or admin)        |
| GET    | `/api/orders`                  | Admin       | List all orders                       |
| PATCH  | `/api/orders/:id/status`        | Admin       | Update an order's status              |

`GET /api/menu` supports query params: `search`, `category`, `restaurantId`, `minPrice`, `maxPrice`.

## Key features implemented

- **Auth**: JWT-based registration/login, bcrypt-hashed passwords, protected routes on both client and server, role-based access (`customer` vs `admin`).
- **Searchable menu**: live search with debounce, restaurant and category filters, all backed by real API queries.
- **Real-time cart**: Context-based cart state persisted to `localStorage`, quantity editing, running subtotal/delivery fee/total.
- **Form validation**: client-side validation (email format, password length/match, required fields, price > 0) plus matching server-side validation as a second line of defense.
- **Order flow**: checkout → server re-validates cart against live menu prices (never trusts client-submitted prices) → order confirmation page → order history with live status badges.
- **Admin dashboard**: add/edit/delete menu items, toggle availability, and update order status (`placed → preparing → out_for_delivery → delivered`, or `cancelled`) with light polling to reflect new orders.
- **Responsive design**: mobile-friendly layouts across menu grid, checkout, and admin tables.

## Notes for production use

This project uses a JSON file (`db.json`) as its datastore, which is great for learning and demos but not for concurrent production traffic. To take this further:

- Swap `lowdb`/`db.json` for a real database (PostgreSQL, MongoDB, etc.) behind the same route/controller structure.
- Move `JWT_SECRET` and other config into a proper secrets manager.
- Add HTTPS, rate limiting, and stricter CORS origins before deploying publicly.
- Add a payment gateway integration if you want real online payments instead of cash/card-on-delivery.
