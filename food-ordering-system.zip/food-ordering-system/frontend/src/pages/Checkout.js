import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { placeOrder } from '../api/api';
import './Checkout.css';

export default function Checkout() {
  const { items, updateQuantity, removeItem, subtotal, deliveryFee, total, clearCart } = useCart();
  const navigate = useNavigate();

  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [placing, setPlacing] = useState(false);

  function validate() {
    const next = {};
    if (!address.trim() || address.trim().length < 8) {
      next.address = 'Enter a complete delivery address (at least 8 characters).';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handlePlaceOrder() {
    setServerError('');
    if (items.length === 0) return;
    if (!validate()) return;

    setPlacing(true);
    try {
      const order = await placeOrder({
        items: items.map((i) => ({ id: i.id, quantity: i.quantity })),
        address: address.trim(),
        paymentMethod
      });
      clearCart();
      navigate(`/orders/${order.id}/confirmation`, { state: { order } });
    } catch (err) {
      setServerError(err.message);
    } finally {
      setPlacing(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="container empty-state">
        <h3>Your cart is empty.</h3>
        <p>Add a few dishes from the menu to get started.</p>
        <Link to="/" className="btn btn-primary">Browse the menu</Link>
      </div>
    );
  }

  return (
    <div className="container checkout-grid">
      <div className="ticket-tape">
        <h2>Your order</h2>
        {items.map((item) => (
          <div className="tape-row" key={item.id}>
            <div className="tape-info">
              <span className="tape-name">{item.name}</span>
              <span className="tape-unit mono">Rs {item.price.toLocaleString()} each</span>
            </div>
            <div className="tape-qty">
              <button
                aria-label={`Decrease quantity of ${item.name}`}
                onClick={() => updateQuantity(item.id, item.quantity - 1)}
              >
                −
              </button>
              <span>{item.quantity}</span>
              <button
                aria-label={`Increase quantity of ${item.name}`}
                onClick={() => updateQuantity(item.id, item.quantity + 1)}
              >
                +
              </button>
            </div>
            <span className="tape-line-total mono">
              Rs {(item.price * item.quantity).toLocaleString()}
            </span>
            <button
              className="tape-remove"
              onClick={() => removeItem(item.id)}
              aria-label={`Remove ${item.name} from cart`}
            >
              ✕
            </button>
          </div>
        ))}

        <div className="tape-divider" />

        <div className="tape-summary-row">
          <span>Subtotal</span>
          <span className="mono">Rs {subtotal.toLocaleString()}</span>
        </div>
        <div className="tape-summary-row">
          <span>Delivery fee</span>
          <span className="mono">Rs {deliveryFee.toLocaleString()}</span>
        </div>
        <div className="tape-summary-row tape-total">
          <span>Total</span>
          <span className="mono">Rs {total.toLocaleString()}</span>
        </div>
      </div>

      <div className="checkout-form">
        <h2>Delivery details</h2>
        {serverError && <div className="banner banner-error">{serverError}</div>}

        <div className="field">
          <label htmlFor="address">Delivery address</label>
          <textarea
            id="address"
            rows={3}
            className={errors.address ? 'invalid' : ''}
            placeholder="House #, street, area, city"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
          {errors.address && <span className="field-error">{errors.address}</span>}
        </div>

        <div className="field">
          <label>Payment method</label>
          <div className="payment-options">
            <label className={`payment-option ${paymentMethod === 'cod' ? 'payment-active' : ''}`}>
              <input
                type="radio"
                name="payment"
                value="cod"
                checked={paymentMethod === 'cod'}
                onChange={() => setPaymentMethod('cod')}
              />
              Cash on delivery
            </label>
            <label className={`payment-option ${paymentMethod === 'card' ? 'payment-active' : ''}`}>
              <input
                type="radio"
                name="payment"
                value="card"
                checked={paymentMethod === 'card'}
                onChange={() => setPaymentMethod('card')}
              />
              Card on delivery
            </label>
          </div>
        </div>

        <button className="btn btn-primary btn-block" onClick={handlePlaceOrder} disabled={placing}>
          {placing ? 'Placing order…' : `Place order — Rs ${total.toLocaleString()}`}
        </button>
      </div>
    </div>
  );
}
