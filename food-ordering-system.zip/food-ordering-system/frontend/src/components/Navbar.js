import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import './Navbar.css';

export default function Navbar() {
  const { user, logout, isAdmin } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();

  return (
    <header className="nav">
      <div className="container nav-inner">
        <Link to="/" className="nav-brand">
          <span className="nav-brand-mark">FH</span>
          FoodHub
        </Link>

        <nav className="nav-links">
          <Link to="/">Menu</Link>
          {user && !isAdmin && <Link to="/orders">My Orders</Link>}
          {isAdmin && <Link to="/admin">Admin</Link>}
        </nav>

        <div className="nav-actions">
          {!isAdmin && (
            <Link to="/checkout" className="nav-cart" aria-label="View cart">
              🧾 Cart
              {itemCount > 0 && <span className="nav-cart-badge">{itemCount}</span>}
            </Link>
          )}
          {user ? (
            <>
              <span className="nav-user">Hi, {user.name.split(' ')[0]}</span>
              <button
                className="btn btn-outline"
                onClick={() => {
                  logout();
                  navigate('/');
                }}
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn-outline">Log in</Link>
              <Link to="/register" className="btn btn-primary">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
