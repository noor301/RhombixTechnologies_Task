import React, { createContext, useContext, useEffect, useState } from 'react';
import { fetchMe, loginUser, registerUser } from '../api/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // On first load, if a token exists, verify it and restore the session
  useEffect(() => {
    const token = localStorage.getItem('foodhub_token');
    if (!token) {
      setLoading(false);
      return;
    }
    fetchMe()
      .then(({ user }) => setUser(user))
      .catch(() => localStorage.removeItem('foodhub_token'))
      .finally(() => setLoading(false));
  }, []);

  async function login(email, password) {
    const { token, user } = await loginUser({ email, password });
    localStorage.setItem('foodhub_token', token);
    setUser(user);
    return user;
  }

  async function register(name, email, password) {
    const { token, user } = await registerUser({ name, email, password });
    localStorage.setItem('foodhub_token', token);
    setUser(user);
    return user;
  }

  function logout() {
    localStorage.removeItem('foodhub_token');
    setUser(null);
  }

  return (
    <AuthContext.Provider
      value={{ user, loading, login, register, logout, isAdmin: user?.role === 'admin' }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside an AuthProvider');
  return ctx;
}
