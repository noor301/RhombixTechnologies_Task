const path = require('path');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

const adapter = new FileSync(path.join(__dirname, '..', 'db.json'));
const db = low(adapter);

// Ensure default shape exists (useful on a fresh/empty db.json)
db.defaults({ users: [], restaurants: [], menuItems: [], orders: [] }).write();

module.exports = db;
