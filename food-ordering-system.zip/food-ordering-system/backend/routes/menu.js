const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../utils/db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/restaurants
router.get('/restaurants', (req, res) => {
  res.json(db.get('restaurants').value());
});

// GET /api/menu?search=&category=&restaurantId=&minPrice=&maxPrice=
router.get('/menu', (req, res) => {
  const { search, category, restaurantId, minPrice, maxPrice } = req.query;
  let items = db.get('menuItems').value();

  if (restaurantId) {
    items = items.filter((i) => i.restaurantId === restaurantId);
  }
  if (category) {
    items = items.filter((i) => i.category.toLowerCase() === category.toLowerCase());
  }
  if (search) {
    const q = search.toLowerCase();
    items = items.filter(
      (i) => i.name.toLowerCase().includes(q) || i.description.toLowerCase().includes(q)
    );
  }
  if (minPrice) items = items.filter((i) => i.price >= Number(minPrice));
  if (maxPrice) items = items.filter((i) => i.price <= Number(maxPrice));

  res.json(items);
});

// GET /api/menu/:id
router.get('/menu/:id', (req, res) => {
  const item = db.get('menuItems').find({ id: req.params.id }).value();
  if (!item) return res.status(404).json({ message: 'Menu item not found.' });
  res.json(item);
});

// ---- Admin-only management ----

// POST /api/menu
router.post('/menu', requireAuth, requireRole('admin'), (req, res) => {
  const { restaurantId, name, description, price, category, image, available } = req.body;

  if (!restaurantId || !name || !price || !category) {
    return res.status(400).json({ message: 'restaurantId, name, price, and category are required.' });
  }
  if (Number(price) <= 0) {
    return res.status(400).json({ message: 'Price must be a positive number.' });
  }

  const newItem = {
    id: uuidv4(),
    restaurantId,
    name: name.trim(),
    description: description || '',
    price: Number(price),
    category: category.trim(),
    image: image || '',
    available: available !== undefined ? Boolean(available) : true
  };

  db.get('menuItems').push(newItem).write();
  res.status(201).json(newItem);
});

// PUT /api/menu/:id
router.put('/menu/:id', requireAuth, requireRole('admin'), (req, res) => {
  const item = db.get('menuItems').find({ id: req.params.id });
  if (!item.value()) return res.status(404).json({ message: 'Menu item not found.' });

  const updates = { ...req.body };
  if (updates.price !== undefined) updates.price = Number(updates.price);

  item.assign(updates).write();
  res.json(item.value());
});

// DELETE /api/menu/:id
router.delete('/menu/:id', requireAuth, requireRole('admin'), (req, res) => {
  const exists = db.get('menuItems').find({ id: req.params.id }).value();
  if (!exists) return res.status(404).json({ message: 'Menu item not found.' });

  db.get('menuItems').remove({ id: req.params.id }).write();
  res.json({ message: 'Menu item deleted.' });
});

module.exports = router;
