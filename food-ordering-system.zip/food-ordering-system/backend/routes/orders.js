const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../utils/db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

const STATUSES = ['placed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled'];
const DELIVERY_FEE = 150;

// POST /api/orders  (customer places an order)
router.post('/', requireAuth, (req, res) => {
  const { items, address, paymentMethod } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: 'Your cart is empty.' });
  }
  if (!address || !address.trim()) {
    return res.status(400).json({ message: 'Delivery address is required.' });
  }
  if (!['cod', 'card'].includes(paymentMethod)) {
    return res.status(400).json({ message: 'Choose a valid payment method.' });
  }

  // Re-validate items and prices against the source of truth (never trust client-sent prices)
  const menuItems = db.get('menuItems').value();
  let subtotal = 0;
  const orderItems = [];

  for (const cartItem of items) {
    const menuItem = menuItems.find((m) => m.id === cartItem.id);
    if (!menuItem) {
      return res.status(400).json({ message: `Item ${cartItem.id} no longer exists.` });
    }
    if (!menuItem.available) {
      return res.status(400).json({ message: `${menuItem.name} is currently unavailable.` });
    }
    const qty = Math.max(1, Number(cartItem.quantity) || 1);
    subtotal += menuItem.price * qty;
    orderItems.push({
      id: menuItem.id,
      name: menuItem.name,
      price: menuItem.price,
      quantity: qty
    });
  }

  const order = {
    id: uuidv4(),
    orderNumber: 'FH-' + Date.now().toString().slice(-8),
    userId: req.user.id,
    customerName: req.user.name,
    items: orderItems,
    subtotal,
    deliveryFee: DELIVERY_FEE,
    total: subtotal + DELIVERY_FEE,
    address: address.trim(),
    paymentMethod,
    status: 'placed',
    createdAt: new Date().toISOString()
  };

  db.get('orders').push(order).write();
  res.status(201).json(order);
});

// GET /api/orders/mine (customer order history)
router.get('/mine', requireAuth, (req, res) => {
  const orders = db.get('orders')
    .filter({ userId: req.user.id })
    .sortBy('createdAt')
    .reverse()
    .value();
  res.json(orders);
});

// GET /api/orders/:id (single order, owner or admin only)
router.get('/:id', requireAuth, (req, res) => {
  const order = db.get('orders').find({ id: req.params.id }).value();
  if (!order) return res.status(404).json({ message: 'Order not found.' });
  if (order.userId !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'You cannot view this order.' });
  }
  res.json(order);
});

// ---- Admin ----

// GET /api/orders (admin: all orders, newest first)
router.get('/', requireAuth, requireRole('admin'), (req, res) => {
  const orders = db.get('orders').sortBy('createdAt').reverse().value();
  res.json(orders);
});

// PATCH /api/orders/:id/status (admin updates order status)
router.patch('/:id/status', requireAuth, requireRole('admin'), (req, res) => {
  const { status } = req.body;
  if (!STATUSES.includes(status)) {
    return res.status(400).json({ message: `Status must be one of: ${STATUSES.join(', ')}` });
  }

  const order = db.get('orders').find({ id: req.params.id });
  if (!order.value()) return res.status(404).json({ message: 'Order not found.' });

  order.assign({ status }).write();
  res.json(order.value());
});

module.exports = router;
